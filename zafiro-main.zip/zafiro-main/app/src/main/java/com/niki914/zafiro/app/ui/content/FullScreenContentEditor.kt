package com.niki914.zafiro.app.ui.content

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.niki914.uikit.button.ZafiroTonalButton
import com.niki914.uikit.infra.component.PageDescriptionText
import com.niki914.uikit.infra.component.SettingsDetailPageDefaults
import com.niki914.uikit.screen.zafiroActionButtonBottomPadding
import com.niki914.uikit.screen.zafiroScreenBottomPadding
import com.niki914.uikit.screen.zafiroScreenTopPadding

/**
 * 整页内容编辑器骨架（infra）：描述文案 + 全页 TextField + 底部保存按钮 + 内联错误。
 * 从 SkillDetailContent 提取；Prompt 编辑页与 Skill 详情页共用。
 * 顶层 chrome（未保存确认、删除确认）仍由调用方经 [com.niki914.zafiro.app.ui.settings.form.EditableSettingsDetailChrome] 提供。
 */
@Composable
internal fun FullScreenContentEditor(
    description: String,
    value: String,
    enabled: Boolean,
    onValueChange: (String) -> Unit,
    actionText: String,
    onActionClick: () -> Unit,
    modifier: Modifier = Modifier,
    actionLoading: Boolean = false,
    inlineErrorText: String? = null,
) {
    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = SettingsDetailPageDefaults.HorizontalPadding)
                .padding(
                    top = zafiroScreenTopPadding(SettingsDetailPageDefaults.VerticalPadding),
                    // 底部预留 = 底部安全距离 + 按钮位高，与吸底按钮的 bottom 同源，避免最后一行被遮挡
                    bottom = zafiroScreenBottomPadding() +
                            SettingsDetailPageDefaults.RootVerticalSpacing +
                            SettingsDetailPageDefaults.ActionButtonReservedHeight,
                ),
            verticalArrangement = Arrangement.spacedBy(
                SettingsDetailPageDefaults.ContentVerticalSpacing,
            ),
        ) {
            PageDescriptionText(text = description)
            TextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                textStyle = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            )
            inlineErrorText?.let { errorText ->
                Text(
                    text = errorText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(
                        horizontal = SettingsDetailPageDefaults.InlineErrorHorizontalPadding,
                    ),
                )
            }
        }

        ZafiroTonalButton(
            text = actionText,
            enabled = enabled,
            isLoading = actionLoading,
            onClick = onActionClick,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(
                    start = SettingsDetailPageDefaults.HorizontalPadding,
                    end = SettingsDetailPageDefaults.HorizontalPadding,
                    bottom = zafiroActionButtonBottomPadding(),
                ),
        )
    }
}
