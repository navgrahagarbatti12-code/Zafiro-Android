package com.niki914.zafiro.app.ui.content

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.niki914.uikit.infra.nav.pageViewModel
import com.niki914.zafiro.app.ui.content.mcp.McpServiceSettingsContent
import com.niki914.zafiro.app.ui.content.mcp.McpSettingsContent
import com.niki914.zafiro.app.ui.model.SettingsViewModel
import com.niki914.zafiro.app.ui.nav.BuiltinToolGroupDetailPage
import com.niki914.zafiro.app.ui.nav.ExecutionRuleDetailPage
import com.niki914.zafiro.app.ui.nav.MaskingRuleDetailPage
import com.niki914.zafiro.app.ui.nav.McpServerDetailPage
import com.niki914.zafiro.app.ui.nav.EnvContextVariableDetailPage
import com.niki914.zafiro.app.ui.nav.PromptEditPage
import com.niki914.zafiro.app.ui.nav.QuickPromptDetailPage
import com.niki914.zafiro.app.ui.nav.SavedConfigDetailPage
import com.niki914.zafiro.app.ui.nav.SettingsProviderPickPage
import com.niki914.zafiro.app.ui.nav.SkillDetailPage
import com.niki914.zafiro.app.ui.nav.TakeoverRuleDetailPage
import com.niki914.zafiro.app.ui.nav.TextActionDetailPage
import com.niki914.zafiro.app.ui.nav.ZafiroPage
import com.niki914.zafiro.app.ui.nav.ZafiroSettingsGroup

@Composable
fun SettingsDetailPageContent(
    group: ZafiroSettingsGroup,
    onPush: (ZafiroPage) -> Unit,
    onBack: () -> Unit,
) {
    val viewModel = pageViewModel<SettingsViewModel>()
    val uiState by viewModel.uiStateFlow.collectAsState()
    val visibleGroups = uiState.sections.flatMap { it.groups }.toSet()
    if (group !in visibleGroups) {
        return
    }

    if (group == ZafiroSettingsGroup.ModelConfig) {
        ModelConfigSettingsContent(
            onBack = onBack,
            onOpenProviderPick = {
                onPush(SettingsProviderPickPage)
            },
            onOpenConfigDetail = { configId, configName ->
                onPush(SavedConfigDetailPage(configId = configId, configName = configName))
            },
            onOpenPromptEdit = {
                onPush(PromptEditPage)
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.Tools) {
        BuiltinToolsSettingsContent(
            onOpenGroupDetail = { groupId ->
                onPush(BuiltinToolGroupDetailPage(groupId))
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.Skills) {
        SkillsSettingsContent(
            onOpenSkillDetail = { id, title ->
                onPush(SkillDetailPage(id, title))
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.QuickPrompts) {
        QuickPromptsSettingsContent(
            onOpenPromptDetail = { title, index, isCreating ->
                onPush(QuickPromptDetailPage(title, index, isCreating))
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.Mcp) {
        McpSettingsContent(
            onOpenServerDetail = { name, index, isCreating ->
                onPush(McpServerDetailPage(name, index, isCreating))
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.Actions) {
        TextActionsSettingsContent(
            onOpenActionDetail = { title, index, isCreating ->
                onPush(TextActionDetailPage(title, index, isCreating))
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.McpService) {
        McpServiceSettingsContent()
        return
    }

    if (group == ZafiroSettingsGroup.Theme) {
        ThemeSettingsContent(onPush = onPush)
        return
    }

    if (group == ZafiroSettingsGroup.GeneralSettings) {
        GeneralSettingsContent(onPush = onPush)
        return
    }

    if (group == ZafiroSettingsGroup.Backup) {
        BackupSettingsContent()
        return
    }

    if (group == ZafiroSettingsGroup.Storage) {
        StorageSettingsContent()
        return
    }

    if (group == ZafiroSettingsGroup.About) {
        AboutSettingsContent()
        return
    }

    if (group == ZafiroSettingsGroup.Memory) {
        MemorySettingsContent()
        return
    }

    if (group == ZafiroSettingsGroup.ContextInjection) {
        EnvContextSettingsContent(
            onOpenVariableDetail = { key, isCreating ->
                onPush(
                    EnvContextVariableDetailPage(
                        variableKey = key,
                        isCreating = isCreating,
                    )
                )
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.RuntimeControl) {
        RuntimeControlSettingsContent()
        return
    }

    if (group == ZafiroSettingsGroup.Takeover) {
        TakeoverSettingsContent(
            onOpenRuleDetail = { id, name, index, isCreating ->
                onPush(
                    TakeoverRuleDetailPage(
                        ruleId = id,
                        ruleName = name,
                        ruleIndex = index,
                        isCreating = isCreating,
                    )
                )
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.ExecutionRules) {
        ExecutionRulesSettingsContent(
            onOpenRuleDetail = { name, index, isCreating ->
                onPush(ExecutionRuleDetailPage(name, index, isCreating))
            },
        )
        return
    }

    if (group == ZafiroSettingsGroup.MaskingRules) {
        MaskingRulesSettingsContent(
            onOpenRuleDetail = { id, name, index, isCreating ->
                onPush(
                    MaskingRuleDetailPage(
                        ruleId = id,
                        ruleName = name,
                        ruleIndex = index,
                        isCreating = isCreating,
                    )
                )
            },
        )
        return
    }

    TODOPageContent()
    return
}
