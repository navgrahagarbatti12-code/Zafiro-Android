package com.niki914.zafiro.settings.model

/**
 * 单次输出上限默认值（max_output_tokens / max_tokens）。
 * 旧默认是 okia 骨架里的 4096，会把长回答和带大参数的工具调用从中间切断
 * （截断的工具调用无法执行，是「工具块一直转圈」的根因）。
 */
const val DEFAULT_MAX_TOKENS: Int = 128_000

/**
 * 上下文窗口默认值（环的分母）。配置里留空时用它。
 * 注意：默认值大于模型真实窗口时，环会显示偏小的占用，压缩门（0.85）迟迟不触发——
 * 所以真实窗口应当填进配置。
 */
const val DEFAULT_CONTEXT_WINDOW_TOKENS: Long = 1_000_000L

data class RuntimeLlmConfig(
    val provider: String = "",
    val endpoint: String = "",
    val apiKey: String = "",
    val model: String = "",
    /** LlmProtocol.wireId，如 "openai-responses"。空串回落默认协议。 */
    val protocol: String = "",
    /** 视觉模型开关（图片输入支持），默认关。 */
    val supportsImages: Boolean = false,
    val prompt: String = "",
    val proxy: String = "",
    val memoryPrompt: String = "",
    val memories: List<String> = emptyList(),
    val takeoverKeywords: List<String> = emptyList(),
    /** 流式空闲超时秒数；null = 不超时（Long.MAX_VALUE）。 */
    val idleTimeoutSeconds: Long? = 60L,
    /** 传输层自动重试次数。 */
    val retryMaxAttempts: Int = 3,
    /** 单次输出上限（max_output_tokens / max_tokens）。 */
    val maxTokens: Int = DEFAULT_MAX_TOKENS,
    /** 上下文窗口（分母）；≤0 由 gateway 落 [DEFAULT_CONTEXT_WINDOW_TOKENS]。 */
    val contextWindowTokens: Long = DEFAULT_CONTEXT_WINDOW_TOKENS,
    /** ThinkingLevel.wireValue；空串 = 不发送思考字段（Provider 默认行为）。 */
    val thinkingLevel: String = "",
    /** 复读检测灵敏度档位；见 [RepetitionSensitivity]。 */
    val repetitionSensitivity: RepetitionSensitivity = RepetitionSensitivity.DEFAULT,
    /** 上下文自动压缩阈值百分比（例如 70 表示 70%，0 表示关闭）。 */
    val compactionThresholdPercent: Int = 70,
    /** 环境与时态上下文注入配置。 */
    val envContext: RuntimeEnvContextConfig = RuntimeEnvContextConfig(),
)

data class RuntimeEnvContextConfig(
    val enabled: Boolean = false,
    val keys: Set<String> = DEFAULT_KEYS,
    val variables: Map<String, String> = emptyMap(),
) {
    companion object {
        const val KEY_DATE = "date"
        const val KEY_TIME = "time"
        const val KEY_DEVICE = "device"
        val DEFAULT_KEYS = setOf(KEY_DATE, KEY_TIME, KEY_DEVICE)
    }
}

enum class RuntimeAgentMemoryMode {
    Disabled,
    SharedMain,
}

data class RuntimeAgentProfile(
    val id: String,
    val name: String,
    val alias: String,
    val enabled: Boolean = true,
    val order: Int = 0,
    val memoryMode: RuntimeAgentMemoryMode = RuntimeAgentMemoryMode.SharedMain,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
)

data class RuntimeAgentValidation(
    val field: String,
    val message: String,
)

data class RuntimeSkillMetadata(
    val id: String,
    val name: String,
    val description: String,
    val relativePath: String,
    val absolutePath: String,
    val absoluteDir: String,
    val enabled: Boolean,
)

data class RuntimeLoadedSkill(
    val id: String,
    val name: String,
    val description: String,
    val relativePath: String,
    val absolutePath: String,
    val absoluteDir: String,
    val content: String,
    val enabled: Boolean,
)

data class RuntimeSkillValidation(
    val field: String,
    val message: String,
)

data class RuntimeMcpServer(
    val name: String,
    val url: String,
    val enabled: Boolean = true,
    val headers: Map<String, String> = emptyMap(),
)

/**
 * 持久化 Python 工具（由 custom_py_tools 创建）条目。
 * code 是工具本体；description/schemaJson 是反射结果的缓存，代码变更后重算覆盖。
 */
data class RuntimeCustomPyTool(
    val name: String,
    val code: String,
    val description: String = "",
    val schemaJson: String = "",
    val enabled: Boolean = true,
    val timeoutMs: Long = DEFAULT_CUSTOM_PY_TOOL_TIMEOUT_MS,
) {
    companion object {
        const val DEFAULT_CUSTOM_PY_TOOL_TIMEOUT_MS: Long = 30_000L
        const val MIN_CUSTOM_PY_TOOL_TIMEOUT_MS: Long = 1_000L
        const val MAX_CUSTOM_PY_TOOL_TIMEOUT_MS: Long = 120_000L
    }
}

data class RuntimeBuiltinToolSetting(
    val name: String,
    val description: String,
    val enabled: Boolean,
)

enum class RuntimeExecutionRuleEnabledMode {
    ALWAYS,
    LOCKED_ONLY,
    DISABLED,

    /** 命中后挂起等待用户确认；无确认渠道（宿主路径）时拒绝。 */
    CONFIRM,
}

data class RuntimeExecutionRule(
    val id: String,
    val name: String,
    val enabledMode: RuntimeExecutionRuleEnabledMode,
    val patterns: List<String>,
)

enum class RuntimeTakeoverTarget {
    NATIVE_ASSISTANT,
    ZAFIRO,
}

data class RuntimeTakeoverRule(
    val id: String,
    val name: String,
    val target: RuntimeTakeoverTarget,
    val enabled: Boolean = true,
    val patterns: List<String>,
)

data class RuntimeMaskingRule(
    val id: String,
    val name: String,
    val enabled: Boolean = true,
    val kind: String = "API_KEY",
    val patterns: List<String>,
) {
    companion object {
        const val FALLBACK_KIND = "UNDEFINED"

        fun isValidKind(kind: String): Boolean {
            val trimmed = kind.trim()
            if (trimmed.isEmpty()) return false
            if (trimmed.contains("{{") || trimmed.contains("}}")) return false
            if (trimmed.contains('\n') || trimmed.contains('\r')) return false
            return true
        }

        fun sanitizeKind(kind: String): String {
            val trimmed = kind.trim()
            return if (isValidKind(trimmed)) trimmed else FALLBACK_KIND
        }
    }
}

data class RuntimeTakeoverSettings(
    val defaultTarget: RuntimeTakeoverTarget = RuntimeTakeoverTarget.ZAFIRO,
    val rules: List<RuntimeTakeoverRule> = emptyList(),
)

const val TAKEOVER_FIELD_NAME: String = "name"
const val TAKEOVER_FIELD_PATTERNS: String = "patterns"

data class RuntimeTakeoverRuleValidation(
    val field: String,
    val message: String,
)

/** 工具校验错误的来源：Code = 用户代码/配置问题，Internal = 应用内部问题。UI 据此选择提示文案。 */
enum class RuntimeToolValidationOrigin {
    Code,
    Internal,
}

data class RuntimeToolValidation(
    val field: String,
    val message: String,
    val origin: RuntimeToolValidationOrigin = RuntimeToolValidationOrigin.Code,
)

/**
 * Zafiro 把自己作为 MCP 服务对外暴露的配置。
 * 默认关闭服务，且仅在白名单内的安全工具默认开放；高危工具（terminal/python）默认关闭。
 * [keepScreenOn] 只影响服务 Running 时的 CPU 防休眠，MCP 调用不要求屏幕常亮。
 */
data class RuntimeMcpServiceConfig(
    val enabled: Boolean = false,
    val port: Int = DEFAULT_PORT,
    val host: String = DEFAULT_HOST,
    val bearerToken: String = "",
    val exposedTools: Set<String> = DEFAULT_EXPOSED_TOOLS,
    val keepScreenOn: Boolean = true,
) {
    fun isToolExposed(toolName: String): Boolean {
        if (toolName.startsWith("mcp__")) {
            return false
        }
        return toolName in exposedTools
    }

    companion object {
        const val DEFAULT_PORT: Int = 8791
        const val MIN_PORT: Int = 1024
        const val MAX_PORT: Int = 65535
        const val DEFAULT_HOST: String = "127.0.0.1"

        val DEFAULT_EXPOSED_TOOLS: Set<String> = setOf(
            "screen_operation",
            "open",
            "screens",
            "screenshot",
            "find_installed_apps",
            "load_skill",
            "notify",
            "view_image",
            "memory",
            "shell",
            "ssh",
        )
    }
}
