package com.niki914.zafiro.chat.agentic.buildin.impl

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenOperationArgsTest {

    @Test
    fun parse_read_defaultWaitMode() {
        val result = parseArguments("""{"operation": "read"}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.Read)
        assertEquals("stable", args.waitMode)
        assertEquals(2000L, args.waitMs)
    }

    @Test
    fun parse_read_explicitStable() {
        val result = parseArguments(
            """{"operation": "read", "wait_mode": "stable", "wait_ms": 3000}"""
        )
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertEquals("stable", args.waitMode)
        assertEquals(3000L, args.waitMs)
    }

    @Test
    fun parse_read_delayMode() {
        val result = parseArguments(
            """{"operation": "read", "wait_mode": "delay", "wait_ms": 3000}"""
        )
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertEquals("delay", args.waitMode)
        assertEquals(3000L, args.waitMs)
    }

    @Test
    fun parse_backwardCompat_delayMs() {
        val result = parseArguments("""{"operation": "read", "delay_ms": 1000}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        // Old delay_ms field maps to wait_mode "delay"
        assertEquals("delay", args.waitMode)
        assertEquals(1000L, args.waitMs)
    }

    @Test
    fun parse_backwardCompat_delayMsWithWaitMode() {
        // When both old and new params are present, wait_mode wins
        val result = parseArguments(
            """{"operation": "tap", "token": "x_1", "delay_ms": 2000, "wait_mode": "stable"}"""
        )
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertEquals("stable", args.waitMode)
        assertEquals(2000L, args.waitMs)
    }

    @Test
    fun parse_tap() {
        val result = parseArguments("""{"operation": "tap", "token": "a3f2_42"}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.Tap)
        assertEquals("a3f2_42", (args.operation as ScreenOp.Tap).token)
        assertEquals("stable", args.waitMode)
        assertEquals(2000L, args.waitMs)
    }

    @Test
    fun parse_setText() {
        val result = parseArguments(
            """{"operation": "set_text", "token": "a3f2_7", "text": "hello"}"""
        )
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.SetText)
        val setText = args.operation as ScreenOp.SetText
        assertEquals("a3f2_7", setText.token)
        assertEquals("hello", setText.text)
    }

    @Test
    fun parse_search() {
        val result = parseArguments("""{"operation": "search", "keywords": ["settings"]}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.Search)
        val search = args.operation as ScreenOp.Search
        assertEquals(listOf("settings"), search.keywords)
        assertEquals("any", search.matchMode)
        assertEquals(10, search.limit)
    }

    @Test
    fun parse_searchWithAllParams() {
        val result = parseArguments(
            """{"operation": "search", "keywords": ["a", "b"], "match_mode": "all", "limit": 5}"""
        )
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.Search)
        val search = args.operation as ScreenOp.Search
        assertEquals(listOf("a", "b"), search.keywords)
        assertEquals("all", search.matchMode)
        assertEquals(5, search.limit)
    }

    @Test
    fun parse_search_stringKeywords() {
        val result = parseArguments("""{"operation": "search", "keywords": "settings"}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.Search)
        val search = args.operation as ScreenOp.Search
        assertEquals(listOf("settings"), search.keywords)
    }

    @Test
    fun parse_search_fallbackText() {
        val result = parseArguments("""{"operation": "search", "text": "settings"}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.Search)
        val search = args.operation as ScreenOp.Search
        assertEquals(listOf("settings"), search.keywords)
    }

    @Test
    fun parse_search_missingKeywordsAndText_fails() {
        val result = parseArguments("""{"operation": "search"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("Missing required field: keywords for operation 'search'") == true
        )
    }

    @Test
    fun parse_shellTap() {
        val result = parseArguments("""{"operation": "tap", "x": 100, "y": 200}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.ShellTap)
        val shellTap = args.operation as ScreenOp.ShellTap
        assertEquals(100, shellTap.x)
        assertEquals(200, shellTap.y)
    }

    @Test
    fun parse_shellSwipe() {
        val result = parseArguments(
            """{"operation": "swipe", "start_x": 0, "start_y": 1000, "end_x": 0, "end_y": 200}"""
        )
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.ShellSwipe)
        val swipe = args.operation as ScreenOp.ShellSwipe
        assertEquals(0, swipe.startX)
        assertEquals(1000, swipe.startY)
        assertEquals(0, swipe.endX)
        assertEquals(200, swipe.endY)
        assertEquals(300L, swipe.duration)
    }

    @Test
    fun parse_shellKey() {
        val result = parseArguments("""{"operation": "key", "code": 4}""")
        assertTrue(result.isSuccess)
        val args = result.getOrThrow()
        assertTrue(args.operation is ScreenOp.ShellKey)
        assertEquals(4, (args.operation as ScreenOp.ShellKey).code)
    }

    @Test
    fun parse_missingOperation_fails() {
        val result = parseArguments("""{}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("Missing required field: operation.") == true
        )
    }

    @Test
    fun parse_unknownOperation_fails() {
        val result = parseArguments("""{"operation": "unknown_op"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("Unknown operation") == true
        )
    }

    @Test
    fun parse_tapWithoutTokenOrXY_fails() {
        val result = parseArguments("""{"operation": "tap"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("Missing required field: x for operation 'tap'") == true
        )
    }

    @Test
    fun parse_invalidJson_fails() {
        val result = parseArguments("not json at all")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("Invalid JSON") == true
        )
    }

    @Test
    fun parse_invalidWaitMode_fails() {
        val result = parseArguments("""{"operation": "read", "wait_mode": "instant"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("wait_mode must be 'stable' or 'delay'") == true
        )
    }

    @Test
    fun parse_delayWithoutWaitMs_fails() {
        val result = parseArguments("""{"operation": "read", "wait_mode": "delay"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("wait_ms is required when wait_mode is 'delay'") == true
        )
    }

    @Test
    fun parse_nonNumericWaitMs_fails() {
        val result = parseArguments("""{"operation": "read", "wait_ms": "abc"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("wait_ms must be a number") == true
        )
    }

    @Test
    fun parse_nonNumericDelayMs_fails() {
        val result = parseArguments("""{"operation": "read", "delay_ms": "abc"}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("delay_ms must be a number") == true
        )
    }

    @Test
    fun parse_waitMsExceedsMax_fails() {
        val result = parseArguments("""{"operation": "read", "wait_ms": 99999}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("wait_ms must be in range 0..60000") == true
        )
    }

    @Test
    fun parse_waitMsNegative_fails() {
        val result = parseArguments("""{"operation": "read", "wait_ms": -1}""")
        assertTrue(result.isFailure)
        assertTrue(
            result.exceptionOrNull()?.message?.contains("wait_ms must be in range 0..60000") == true
        )
    }

}
